from importlib.metadata import version

from .main import Doc as Doc

__version__ = version("annotated-doc")
