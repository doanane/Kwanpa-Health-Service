from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from sqlalchemy.orm import Session
import os
import uuid
from app.database import get_db
from app.auth.security import get_current_active_user
from app.models.user import User, UserProfile, UserDevice
from app.schemas.user import UserProfileCreate, UserProfileResponse, UserDeviceCreate, UserDeviceResponse

router = APIRouter(prefix="/users", tags=["users"])

# Ensure upload directory exists
os.makedirs("uploads", exist_ok=True)

@router.post("/complete-profile", response_model=UserProfileResponse)
async def complete_profile(
    profile_data: UserProfileCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    # Check if profile already exists
    existing_profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    
    # Calculate BMI
    height_m = profile_data.height / 100  # convert cm to meters
    bmi = int(profile_data.weight / (height_m * height_m))
    
    if existing_profile:
        # Update existing profile
        for field, value in profile_data.dict().items():
            setattr(existing_profile, field, value)
        existing_profile.bmi = bmi
        existing_profile.profile_completed = True
    else:
        # Create new profile
        existing_profile = UserProfile(
            user_id=current_user.id, 
            **profile_data.dict(),
            bmi=bmi,
            profile_completed=True
        )
        db.add(existing_profile)
    
    db.commit()
    db.refresh(existing_profile)
    return existing_profile

@router.get("/profile", response_model=UserProfileResponse)
async def get_profile(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Profile not found. Please complete your profile first."
        )
    return profile

@router.post("/link-device", response_model=UserDeviceResponse)
async def link_device(
    device_data: UserDeviceCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    # Check if device already linked
    existing_device = db.query(UserDevice).filter(
        UserDevice.user_id == current_user.id,
        UserDevice.device_id == device_data.device_id
    ).first()
    
    if existing_device:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Device already linked"
        )
    
    device = UserDevice(user_id=current_user.id, **device_data.dict())
    db.add(device)
    db.commit()
    db.refresh(device)
    return device

@router.get("/devices", response_model=list[UserDeviceResponse])
async def get_devices(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    devices = db.query(UserDevice).filter(UserDevice.user_id == current_user.id).all()
    return devices

@router.delete("/devices/{device_id}")
async def unlink_device(
    device_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    device = db.query(UserDevice).filter(
        UserDevice.id == device_id,
        UserDevice.user_id == current_user.id
    ).first()
    
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    db.delete(device)
    db.commit()
    return {"message": "Device unlinked successfully"}

@router.post("/upload-profile-image")
async def upload_profile_image(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_active_user)
):
    # Validate file type
    if not file.content_type.startswith('image/'):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only image files are allowed"
        )
    
    # Generate unique filename
    file_extension = file.filename.split('.')[-1]
    filename = f"{current_user.patient_id}_{uuid.uuid4().hex}.{file_extension}"
    file_path = os.path.join("uploads", filename)
    
    # Save file
    with open(file_path, "wb") as buffer:
        content = await file.read()
        buffer.write(content)
    
    return {
        "message": "File uploaded successfully",
        "filename": filename,
        "file_url": f"/uploads/{filename}"
    }